<?php
namespace Rvs\InventoryReportApi\Model;

use Magento\Framework\App\RequestInterface;
use \Magento\Framework\Controller\Result\JsonFactory;
use Bss\InventoryReport\Model\ReportFactory;
use Bss\InventoryReport\Model\ResourceModel\Report\CollectionFactory;

class InventoryManagement {

    private $reportFactory;
    private $collectionFactory;
    private $request;

    public function __construct(
        ReportFactory $reportFactory,
        CollectionFactory $collectionFactory,
        RequestInterface $request
    ){
        $this->reportFactory = $reportFactory;
        $this->collectionFactory = $collectionFactory;
        $this->request = $request;
    }
    /**
     * GET for Post api
     * @api
     * @param string $param
     * @return JsonFactory|object
     */
    public function getInventory($product_id){
        $reports_coll = $this->collectionFactory->create()->load();
        $reports_coll->addFieldToFilter('product_id', ['eq' => $product_id]);
        return $reports_coll->getData();
    }

    public function updateInventory(){
        $report = $this->reportFactory->create()->load($this->request->getParam('reportId'));
        $report->setNote($report->getNote()."mynote");
        if ($report->save()){
            echo "yeah data saved";
        }else{
            echo "oh data is not saved";
        }
        var_dump($report->getData());

        echo "update function is working and id is accessible ";
    }

    public function deleteInventory(){
        var_dump($this->request->getParams());
        echo "delete function is working and id is accessible ";
    }

    public function addInventory(){
        $report = $this->reportFactory->create();
        $product_id = $this->request->getParam('product_id')?$this->request->getParam('product_id'):'';
        $time = $this->request->getParam('time')?$this->request->getParam('time'):'';
        $qty_after = $this->request->getParam('qty_after')?$this->request->getParam('qty_after'):'';
        $stock_status = $this->request->getParam('stock_status')?$this->request->getParam('stock_status'):'';
        $note = $this->request->getParam('note')?$this->request->getParam('note'):'';
        $user = $this->request->getParam('user')?$this->request->getParam('user'):'';
        $product_name = $this->request->getParam('product_name')?$this->request->getParam('product_name'):'';
        $product_sku = $this->request->getParam('product_sku')?$this->request->getParam('product_sku'):'';
        $qty_change = $this->request->getParam('qty_change')?$this->request->getParam('qty_change'):'';
        $shipment_entity_id = $this->request->getParam('shipment_entity_id')?$this->request->getParam('shipment_entity_id'):'';
        $credit_entity_id = $this->request->getParam('credit_entity_id')?$this->request->getParam('credit_entity_id'):'';
        $source_code = $this->request->getParam('source_code')?$this->request->getParam('source_code'):'';
        $saleable_qty = $this->request->getParam('saleable_qty')?$this->request->getParam('saleable_qty'):'';
        $saleable_qty_change = $this->request->getParam('saleable_qty_change')?$this->request->getParam('saleable_qty_change'):'';
        $stock_id = $this->request->getParam('stock_id')?$this->request->getParam('stock_id'):'';
        $order_increment_id = $this->request->getParam('order_increment_id')?$this->request->getParam('order_increment_id'):'';
        $customer_id = $this->request->getParam('customer_id')?$this->request->getParam('customer_id'):'';
        $invoice_entity_id = $this->request->getParam('invoice_entity_id')?$this->request->getParam('invoice_entity_id'):'';
        $bss_qty_reason_change = $this->request->getParam('bss_qty_reason_change')?$this->request->getParam('bss_qty_reason_change'):'';

        $report->setProductId($product_id);
        $report->setTime($time);
        $report->setQtyAfter($qty_after);
        $report->setStockStatus($stock_status);
        $report->setNote($note);
        $report->setUser($user);
        $report->setProductName($product_name);
        $report->setProductSku($product_sku);
        $report->setQtyChange($qty_change);
        $report->setShipmentEntityId($shipment_entity_id);
        $report->setCreditEntityId($credit_entity_id);
        $report->setSourceCode($source_code);
        $report->setSaleableQty($saleable_qty);
        $report->setSaleableQtyChange($saleable_qty_change);
        $report->setStockId($stock_id);
        $report->setOrderIncrementId($order_increment_id);
        $report->setCustomerId($customer_id);
        $report->setInvoiceEntityId($invoice_entity_id);
        $report->setBssQtyReasonChange($bss_qty_reason_change);
        if ($report->save()){
            return ['msg'=>'success'];
        }else{
            return ['msg'=>'Failed'];
        }
    }

}
