<?php
namespace Rvs\InventoryReportApi\Api;


use \Magento\Framework\Controller\Result\Json;

interface InventoryManagementInterface {
    /**
     * GET for Report api
     * @api
     * @param string $productId
     * @return void
     */

    public function getInventory($productId);

    /**
     * GET for Report api
     * @api
     * @param string $productId
     * @return void
     */

    public function updateInventory();

    /**
     * GET for Report api
     * @api
     * @param string $productId
     * @return void
     */

    public function deleteInventory();

    /**
     * GET for Report api
     * @api
     * @param string $productId
     * @return void
     */

    public function addInventory();

}
