<?php

namespace Rvs\TriggerApi\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Exception\InputException;

class Products implements \Magento\Framework\Event\ObserverInterface
{
    private $apiUrl;
    private $auth_token;
    private $deploymentConfig;
    private $logger;
    private $orderRepository;

    public function __construct(
        DeploymentConfig $deploymentConfig,
        \Magento\Sales\Model\OrderRepository $orderRepository
    )
    {
        $this->orderRepository = $orderRepository;
        $this->deploymentConfig = $deploymentConfig;
       
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $this->logger = new \Zend\Log\Logger();
        $this->logger->addWriter($writer);

        if (!empty($this->deploymentConfig->get('rvs/auth_token'))) {
            $this->auth_token = $this->deploymentConfig->get('rvs/auth_token');
        }else{
            throw new InputException(__('Laravel Auth Token is empty'));
        }

        if (!empty($this->deploymentConfig->get('rvs/domain'))) {
            $this->apiUrl = $this->deploymentConfig->get('rvs/domain')."/api/trigger/update";
        }else{
            throw new InputException(__('Laravel App URL is empty'));
        }
    }

    public function execute(Observer $observer)
    {

        switch ($observer->getEvent()->getName()) {
            case "catalog_product_save_after";
                $product = $observer->getEvent()->getProduct();
                $this->catalogProductSaveAfter($product);
                break;
                // case "sales_order_place_after";
            case "sales_order_save_commit_after";
                $order = $observer->getEvent()->getOrder();  
                $this->orderSaveAfter($order);
                break;
            case "sales_order_creditmemo_save_after";
                $orderId = $observer->getEvent()->getCreditmemo()->getOrderId();
                $this->creditMemoSaveAfter($orderId);
                break;
        }
      
    }

    public function catalogProductSaveAfter($product)
    {
        $data = [
            "auth_token" => $this->auth_token,
            "type" => "sku",
            "value" => $product->getSku()
        ];
        
        $fields_string = http_build_query($data);

        //open connection
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch,CURLOPT_POST, true);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

        //So that curl_exec returns the contents of the cURL; rather than echoing it
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 

        $result = curl_exec($ch);

        // $this->logger->info($result);
        $result = json_decode($result);
        if (!$result->success) {
            throw new InputException(__($result->message));
        }
    }

    public function orderSaveAfter($order)
    {
        // echo "<pre>";
        // print_r($order->debug());
        // die();
        // $this->logger->info('order');

        $data = [
            "auth_token" => $this->auth_token,
            "type" => "order",
            "value" => []
        ];

        $value = [
            "increment_id" => $order->getIncrementId(),
            "entity_id" => $order->getId(),
            "items" => []
        ];


        // print_r($value);
        // die();

        foreach ($order->getAllItems() as $product) {
            if(!empty($product['qty_backordered'])){
                $backorder = 1;
            }else{
                $backorder = 0;
            }

            $value['items'][] = [
                'entity_id' => $product['product_id'],
                'is_preorder' => $backorder
            ];
        }

        $data['value'] = json_encode($value);

        $fields_string = http_build_query($data);

        //open connection
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch,CURLOPT_POST, true);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

        //So that curl_exec returns the contents of the cURL; rather than echoing it
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 

        $result = curl_exec($ch);

        $this->logger->info($result);

        $result = json_decode($result);
        if (!$result->success) {
            throw new InputException(__($result->message));
        }


        // $this->logger->info('order');

    }

    public function creditMemoSaveAfter($orderId)
    {
        $data = [
            "auth_token" => $this->auth_token,
            "type" => "credit_memo",
            "value" => $orderId
        ];
        
        $fields_string = http_build_query($data);

        //open connection
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch,CURLOPT_POST, true);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

        //So that curl_exec returns the contents of the cURL; rather than echoing it
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 

        $result = curl_exec($ch);
        $result = json_decode($result);
        if (!$result->success) {
            throw new InputException(__($result->message));
        }


    }

}